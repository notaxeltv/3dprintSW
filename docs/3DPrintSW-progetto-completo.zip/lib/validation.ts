import { z } from "zod";

export const productVariantSchema = z.object({
  label: z.string().trim().optional().nullable(),
  height: z.coerce.number().min(0, "Non può essere negativa"),
  width: z.coerce.number().min(0, "Non può essere negativa"),
  depth: z.coerce.number().min(0, "Non può essere negativa"),
  price: z.coerce.number().min(0, "Non può essere negativo"),
  publicPrice: z.coerce.number().min(0).optional().nullable(),
});

export type ProductVariantInput = z.infer<typeof productVariantSchema>;

export const productImageSchema = z.object({
  url: z.string().trim().min(1, "URL immagine obbligatoria"),
  caption: z.string().trim().optional().nullable(),
});

export type ProductImageInput = z.infer<typeof productImageSchema>;

export const productSchema = z.object({
  name: z.string().trim().min(1, "Il nome è obbligatorio"),
  description: z.string().trim().optional().nullable(),
  category: z.string().trim().optional().nullable(),
  subcategory: z.string().trim().optional().nullable(),
  imageUrl: z.string().trim().optional().nullable(),
  material: z.string().trim().optional().nullable(),
  printHours: z.coerce.number().min(0).optional().nullable(),
  costPerUnit: z.coerce.number().min(0, "Il costo non può essere negativo"),
  price: z.coerce.number().min(0, "Il prezzo non può essere negativo"),
  publicPrice: z.coerce.number().min(0, "Il prezzo al pubblico è obbligatorio"),
  minStock: z.coerce.number().int().min(0).optional(),
  variants: z.array(productVariantSchema).optional(),
  images: z.array(productImageSchema).optional(),
});

export type ProductInput = z.infer<typeof productSchema>;

const optionalUrl = z.string().trim().optional().nullable();

export const settingsSchema = z.object({
  companyName: z.string().trim().min(1, "Il nome dell'azienda è obbligatorio"),
  logoUrl: z.string().trim().optional().nullable(),
  instagramUrl: optionalUrl,
  facebookUrl: optionalUrl,
  tiktokUrl: optionalUrl,
  youtubeUrl: optionalUrl,
  whatsappUrl: optionalUrl,
  telegramUrl: optionalUrl,
  linkedinUrl: optionalUrl,
  xUrl: optionalUrl,
  websiteUrl: optionalUrl,
  email: optionalUrl,
  siteDescription: z.string().trim().optional().nullable(),
  legalAddress: z.string().trim().optional().nullable(),
});

export type SettingsInput = z.infer<typeof settingsSchema>;

export const printLogSchema = z.object({
  productId: z.string().min(1, "Seleziona un modello"),
  quantity: z.coerce.number().int().positive("La quantità deve essere maggiore di 0"),
  unitCost: z.coerce.number().min(0).optional(),
  printedAt: z.string().optional(),
  notes: z.string().trim().optional().nullable(),
});

export type PrintLogInput = z.infer<typeof printLogSchema>;

export const saleLogSchema = z.object({
  productId: z.string().min(1, "Seleziona un modello"),
  quantity: z.coerce.number().int().positive("La quantità deve essere maggiore di 0"),
  unitPrice: z.coerce.number().min(0).optional(),
  soldAt: z.string().optional(),
  buyer: z.string().trim().optional().nullable(),
  notes: z.string().trim().optional().nullable(),
});

export type SaleLogInput = z.infer<typeof saleLogSchema>;

export const loginSchema = z.object({
  username: z.string().trim().min(1, "Username obbligatorio"),
  password: z.string().min(1, "Password obbligatoria"),
});

export type LoginInput = z.infer<typeof loginSchema>;

export const shopCreateSchema = z.object({
  name: z.string().trim().min(1, "Il nome del negozio è obbligatorio"),
  username: z.string().trim().min(3, "Username di almeno 3 caratteri"),
  password: z.string().min(6, "Password di almeno 6 caratteri"),
});

export type ShopCreateInput = z.infer<typeof shopCreateSchema>;

export const shopUpdateSchema = z.object({
  name: z.string().trim().min(1).optional(),
  username: z.string().trim().min(3).optional(),
  password: z.string().min(6).optional(),
  active: z.boolean().optional(),
});

export type ShopUpdateInput = z.infer<typeof shopUpdateSchema>;

export const shopMarkupSchema = z.object({
  productId: z.string().min(1),
  markupPercent: z.coerce.number().min(0, "Il ricarico non può essere negativo"),
});

export type ShopMarkupInput = z.infer<typeof shopMarkupSchema>;

export const shopSaleSchema = z.object({
  productId: z.string().min(1, "Seleziona un modello"),
  variantId: z.string().optional().nullable(),
  quantity: z.coerce.number().int().positive("La quantità deve essere maggiore di 0"),
  unitRetailPrice: z.coerce.number().min(0).optional(),
  soldAt: z.string().optional(),
  buyer: z.string().trim().optional().nullable(),
  notes: z.string().trim().optional().nullable(),
});

export type ShopSaleInput = z.infer<typeof shopSaleSchema>;

export const shopOrderItemSchema = z.object({
  productId: z.string().min(1),
  variantId: z.string().optional().nullable(),
  quantity: z.coerce.number().int().positive("La quantità deve essere maggiore di 0"),
});

export const shopOrderCreateSchema = z.object({
  notes: z.string().trim().optional().nullable(),
  items: z.array(shopOrderItemSchema).min(1, "Aggiungi almeno un articolo all'ordine"),
});

export type ShopOrderCreateInput = z.infer<typeof shopOrderCreateSchema>;

export const shopOrderStatusSchema = z.object({
  status: z.enum(["PENDING", "CONFIRMED", "COMPLETED", "CANCELLED"]),
});

export type ShopOrderStatusInput = z.infer<typeof shopOrderStatusSchema>;
